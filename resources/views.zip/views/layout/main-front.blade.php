@include('layout.header-front')
@yield('main')
@include('layout.footer-front')
