@extends('layout.main-front')
@section('title') @if( ! empty($title)) {{ $title }} | @endif @parent @endsection

@section('main')

    <div class="jumbotron jumbotron-xs">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-lg-12">
                    <h2>@lang('app.contact_with_us')</h2>
                </div>
            </div>
        </div>
    </div>

<div class="container" style="margin-top: 65px;">
        <div class="row">
             <div class="col-md-12">
                
           
            <div class="col-md-3">

                <form>
                    <!--<legend><span class="glyphicon glyphicon-globe"></span> @lang('app.our_office')</legend>-->
                     <legend><span class="glyphicon glyphicon-globe"></span> Our Office Location</legend>
                    <address>
                        <!--<strong>{{ get_text_tpl(get_option('footer_company_name')) }}</strong>-->
                        @if(get_option('footer_address'))
                            <br />
                            <i class="fa fa-map-marker"></i>
                            MAGAS International LLC ,<br>
                            <!--MAGAS Accounting & Auditing Services-->
                            Office 901-A5, Gulf Tower, Block A2,<br>
                            PO Box 122705, Oud Mehta, Dubai, UAE
                            <!--{!! get_option('footer_address') !!}-->
                        @endif
                        @if(get_option('site_phone_number'))
                            <br><i class="fa fa-phone"></i>
                            <abbr title="Phone">{!! get_option('site_phone_number') !!}</abbr>
                        @endif

                    </address>

                    @if(get_option('site_email_address'))
                        <address>
                            <strong>@lang('app.email')</strong>
                            <br> <i class="fa fa-envelope-o"></i>
                            <a href="mailto:{{ get_option('site_email_address') }}"> {{ get_option('site_email_address') }} </a>
                        </address>
                    @endif

                </form>

                <div class="well well-sm">
                    <form action="" method="post"> @csrf

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group {{ $errors->has('name')? 'has-error':'' }}">
                                    <label for="name">@lang('app.name')</label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="@lang('app.enter_name')" value="{{ old('name') }}" required="required" />
                                    {!! $errors->has('name')? '<p class="help-block">'.$errors->first('name').'</p>':'' !!}
                                </div>
                                <div class="form-group {{ $errors->has('email')? 'has-error':'' }}">
                                    <label for="email">@lang('app.email_address')</label>
                                    <div class="input-group">
                                <span class="input-group-addon">
                                    <span class="glyphicon glyphicon-envelope"></span>
                                </span>
                                        <input type="email" class="form-control" id="email" placeholder="@lang('app.enter_email_address')" name="email" value="{{ old('email') }}" required="required" />
                                    </div>
                                    {!! $errors->has('email')? '<p class="help-block">'.$errors->first('email').'</p>':'' !!}

                                </div>

                                <div class="form-group {{ $errors->has('message')? 'has-error':'' }}">
                                    <label for="name">@lang('app.message')</label>
                                    <textarea name="message" id="message" class="form-control" required="required" placeholder="@lang('app.message')">{{ old('message') }}</textarea>
                                    {!! $errors->has('message')? '<p class="help-block">'.$errors->first('message').'</p>':'' !!}
                                </div>
                                
                                  <div class="form-group">
                            <label for="code">Affiliate Code</label>

                          
                                <select class="form-control select2" name="aff_code">
                                    <option value="">Select Code</option>
                                    @foreach($query as $queries)
                                        <option value="{{ $queries->affiliate_code }}">{{ $queries->affiliate_code }}</option>
                                    @endforeach
                                </select>
                              

                           
                        </div>


                            </div>
<input type ="hidden" name="rating" id="rating"  >
<input type ="hidden" name="fullpageurl" id="fullpageurl"  value="<?php echo url()->full();?>">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" id="btnContactUs"> @lang('app.send_message')</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!--<div class="col-md-4">-->
            <!--    {!! get_option('google_map_embedded_code') !!}-->
            <!--</div>-->
            
                 
               <div class="col-md-2">
                {!! get_option('google_map_embedded_code') !!}
            </div>
            <div class="col-md-5">
                </div>
             <div class="col-md-2">
                 	 <a class="twitter-timeline" data-tweet-limit="1" data-width="30"
  data-height="0" href="https://twitter.com/magasintl?ref_src=twsrc%5Etfw">Tweets by magasintl</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
                 </div>
                  </div>
        </div>
       
    </div>
     <div class="row">
          
            
        </div>

@endsection

@section('page-js')


    <script>
        @if(session('success'))
        toastr.success('{{ session('success') }}', '<?php echo trans('app.success') ?>', toastr_options);
        @endif
    </script>
@endsection
