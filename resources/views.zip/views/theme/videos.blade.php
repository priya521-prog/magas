@extends('layout.main-front')
@section('title') @if( ! empty($title)) {{ $title }} | @endif @parent @endsection

@section('main')


	<div class="main">
            
		<div class="custom-container">
        
               
       
			<div class="listingbody">
			    		
				<div class="innerListingbody">
				   
				    <!--<div class="innerheading red" style="float:rght">  <li> <a href="{{ route('bizz1') }}">POST A WHITEPAPER</a> </li></div>-->
					<div class="innerheading violet">
						VIDEOS
					</div>
<div class="main" style="margin-top:-29px">
          
		<div class="custom-container">
<div style="margin-bottom:100px;width:100%">
<div class="tab-content responsive">
	<div class="tab-pane active" id="home" role="tabpanel">
		<div class="container-fluid">
			<div class="row mt-3">
				
				<div class="col-md-12" style="padding: 0;">
				    <div class="col-md-3">	<div class="topvideoprt">
											
											<iframe width="100%" height="200" src="https://www.youtube.com/embed/rSGlysudtY8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div></div>
										 <div class="col-md-3">	<div class="topvideoprt">
											
										<iframe width="100%" height="200" src="https://www.youtube.com/embed/hhLt8Tuwu7o" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div></div>
										 <div class="col-md-3">	<div class="topvideoprt">
											
											<iframe width="100%" height="200"src="https://www.youtube.com/embed/8Hwyus7MAqg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div></div>
										 <div class="col-md-3">	<div class="topvideoprt">
											
											 <iframe width="100%" height="200" src="https://www.youtube.com/embed/SazITH8P8xA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div></div>
				
				</div>
			</div>
		</div>
	</div>
	<div class="tab-pane" id="profile" role="tabpanel">
		<div class="container-fluid">
			<div class="row mt-3">
				<div class="col-12">

					<p id="seconddivajax"></p>
				</div>
				
			</div>
		</div>
	</div>
	<div class="tab-pane" id="messages" role="tabpanel">
		<div class="container-fluid">
			<div class="row mt-3">
				<div class="col-12">

					<div class="row mt-3">
				<div class="col-12">
          <!--
					<p class='santhosheeee' ><img src='images/pointimg.png' />&nbsp;&nbsp;
<a class='newsheadlines' href='downloads/MAGASBrochure.pdf' target='_blank'>Magas Brochure</a>
			</p>
    -->
      
<!--<p class='santhosheeee'><img src='images/pointimg.png' />&nbsp;&nbsp;-->
<!--<a class='newsheadlines' href='downloads/MagasTeaser.pdf' target='_blank'>Magas Teaser</a>-->
<!--			</p>-->

<!--
<p class='santhosheeee'><img src='images/pointimg.png' />&nbsp;&nbsp;
<a class='newsheadlines' href='downloads/Whitepapers/VATPresentation.pdf' target='_blank'>VAT Presentation</a>
-->

<!--			</p>-->
		
					
				</div>
			</div>
				</div>
			</div>
		</div>
	</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
      @endsection

