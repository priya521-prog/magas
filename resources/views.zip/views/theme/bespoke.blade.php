@extends('layout.main-front')
@section('title') @if( ! empty($title)) {{ $title }} | @endif @parent @endsection
@section('main')
<style type="text/css">
    table{
        color:#1e2152;
        border: 1px solid black;
    }
    .price-buy {
    background: #1e2152;
    display: inline-block;
    color: #FFF;
        padding: 4px 20px;

   
}
td{
    border:1px solid black;
}
th{
    border:1px solid black;
}
tr{
    border:1px solid black;
}
body .section.packages-content .box .table>tbody>tr>td {
    padding: 10px 25px;
    box-sizing: border-box;
    border: 1px solid black;
}
    .body .section.packages-content .box .table>thead>tr>th:nth-child(2) {
    width: 22%;
    border: 1px solid black;
}
</style>
<div class="body packages">

            <div class="main">
                <div class="section packages-content" style="margin-bottom: 150px;">
                    <div class="tabpanel">
                        <div class="custom-container">
                            <div class="alacarte-menu" style="margin-top: 30px;">
                                <div class="tabpanel">
                                    <ul>
                                       
                                        <li class="each-form-tab active" onclick="showTab('p-tab', 'p-content');">
                                            <div class="curved-buttons">
                                               BESPOKE
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                                <ul class="nav nav-tabs fullnavtablog">
                                    <li class="active">
<!--                                        <a  style="cursor: pointer;" href="{{ asset('assets/Bespoke Solutions.pdf-->
<!--') }}" download>-->
<!--                                            Download-->
<!--                                        </a>-->
                                    </li>
                                </ul>
                            </div>
                            <div class="box">
                                <!--<div class="a-content tab">-->
                                <!--    À LA CARTE-->
                                <!--    <div class="clearfix"></div>-->
                                <!--</div>-->
                                <div class="p-content tab">
                                    <div class="table-responsive">          
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    
                                                    <th>
                                                       BESPOKE SOLUTIONS
                                                    </th>
                                                    <th>
                                                       SPECIFICATIONS
                                                    </th>
                                                    <th>
                                                       NOTES
                                                    </th>
                                                    <!--<th>-->
                                                    <!--   ONE-OFF-->
                                                    <!--</th>-->
                                                    <!--<th>-->
                                                    <!--   MONTHLY-->
                                                    <!--</th>-->
                                                    <!--<th>-->
                                                    <!--   YEARLY<span style="color:rgba(238, 22, 95, 0.96)">(USD)</span>-->
                                                    <!--</th>-->
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr><td style="color:#1e2152;"><b>SLIDERS<br>W.HYPERLINK OPTION</b></td><td>Appears on the home <br>page</td><td>For a Week's Compaign/<br>One week free if booked <br>Monthly</td>
                                                <!--<td>-</td>-->
                                                <!--<td style="border:1px solid black;">-</td><td style="border:1px solid black;">-</td>-->
                                                </tr>
                                                  <tr><td style="color:#1e2152;"><b>SLIDER1</b></td><td>1162X340</td><td></td>
<!--                                                      <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="299">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $299</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                      </td>-->
<!--                                                      <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="999">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $999</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                      </td>-->
<!--                                                      <td style="border:1px solid black;">-</td>-->
                                                      
                                                      </tr>
                                                  <tr><td style="color:#1e2152;"><b>SLIDER2</b></td><td>1162X340</td><td>-</td>
<!--                                                  <td><div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="249">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $249</button>-->
<!--                </form>-->


<!--                                                        </div></td>-->
<!--                                                  <td><div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="749">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $749</button>-->
<!--                </form>-->


<!--                                                        </div></td>-->
<!--                                                  <td style="border:1px solid black;">-</td>-->
                                                  
                                                  </tr>
                                                  <tr><td style="color:#1e2152;"><b>SLIDER3</b></td><td>1162X340</td><td></td>
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="199">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $199</button>-->
<!--                </form>-->


<!--                                                        </div>-->
<!--                                                  </td>-->
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="599">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $599</button>-->
<!--                </form>-->


<!--                                                        </div>-->
<!--                                                  </td><td style="border:1px solid black;">-</td>-->
                                                  
                                                  </tr>
                                                  <tr><td style="color:#1e2152;"><b>SLIDER4</b></td><td>1162X340</td><td></td>
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="149">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $149</button>-->
<!--                </form>-->


<!--                                                        </div>-->
<!--                                                  </td>-->
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="449">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $449</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                  </td>-->
<!--                                                  <td style="border:1px solid black;">-</td>-->
                                                  
                                                  </tr>
                                                  <tr><td style="color:#1e2152;"><b>SLIDER5</b></td><td>1162X340</td><td></td>
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="99">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $99</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                  </td>-->
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="299">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $299</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                  </td>-->
<!--                                                  <td style="border:1px solid black;">-</td>-->
                                                  
                                                  </tr>
                                                  <tr><td style="color:#1e2152;"><b>PREMIUM BANNERS<br>W.HYPERLINK OPTION</b></td><td>248X211</td><td>For a Week's Compaign/One week free <br>if booked Monthly</td>
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="99">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $99</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                  </td>-->
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="299">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $299</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                  </td><td style="border:1px solid black;">-</td>-->
                                                  
                                                  </tr>
                                                  <tr><td style="color:#1e2152;"><b>DIGITAL MARKETING</b></td><td>SEO+SMM+Push & Pull<br> Marketing+Lead Genera<br>tion</td><td>Minimum 12 Weeks/Two<br>Months Off if booked</td>
<!--                                                  <td></td>-->
<!--                                                  <td>-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="999">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $999</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                  </td>-->
<!--                                                  <td style="border:1px solid black;">-->
<!--                                                      <div class="link">-->

<!--<form action="https://www.paypal.com/cgi-bin/webscr" method="post" name="frmPayPal1">-->

<!--                      <input type="hidden" name="business" value="info@magas.ae">-->

<!--                      <input type="hidden" name="cmd" value="_xclick">-->

<!--                      <input type="hidden" name="item_name" value="It Solution Stuff">-->

<!--                      <input type="hidden" name="item_number" value="2">-->

<!--                      <input type="hidden" name="amount" value="9,999">-->

<!--                      <input type="hidden" name="no_shipping" value="1">-->

<!--                      <input type="hidden" name="currency_code" value="USD">-->

<!--                      <input type="hidden" name="cancel_return" value="https://www.magas.services/paypal/cancel.php">-->

<!--                      <input type="hidden" name="return" value="https://www.magas.services/paypal/success.php">  -->

<!--                    <button class="custom-button" href="#"><span>Buy</span> $9,999</button>-->
<!--                </form>-->


<!--                                                        </div> -->
<!--                                                  </td>-->
                                                  </tr>
                                                  <tr><td style="color:#1e2152;"><b>EVENT MICRO SITES/<br>GRAPHICS & WEB DESIGNING</b></td><td>Customised Solutions</td><td>Brochure Sites offshoot of<br>MAGAS/Price starting from</td>
            <!--                                      <td colspan="3" style="text-align:center"><a href="{{ route('contact_us') }}" target="_blank">-->
            <!--  <button class="price-buy">REQUEST FOR A QUOTE</button>-->
            <!--</a></td>-->
            </tr>
                                                  <tr><td style="color:#1e2152;"><b>OPINION POLLS<br>RESEARCH<br>SURVEYS</b></td><td>Customised Solutions</td><td></td>
              <!--                                    <td colspan="3" style="text-align:center"><a href="{{ route('contact_us') }}" target="_blank">-->
              <!--<button class="price-buy">REQUEST FOR A QUOTE</button></td>-->
              </tr>
                                                  <tr><td style="color:#1e2152;"><b>SMS BLASTS</b></td><td>Customised Solution based on number of targeted user of MAGAS</td><td></td>
              <!--                                    <td colspan="3" style="text-align:center"><a href="{{ route('contact_us') }}" target="_blank">-->
              <!--<button class="price-buy">REQUEST FOR A QUOTE</button></td>-->
              </tr>
                                                  <tr><td style="color:#1e2152;"><b>EMAIL BLASTS</b></td><td>Customised Solution based on number of targeted user of MAGAS</td><td></td>
              <!--                                    <td colspan="3" style="text-align:center"><a href="{{ route('contact_us') }}" target="_blank">-->
              <!--<button class="price-buy">REQUEST FOR A QUOTE</button></td>-->
              </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                             <a href="{{ route('contact_us') }}" target="_blank">
              <button class="price-buy">REQUEST FOR A QUOTE</button></a>
                        </div>
                        
                                                 
                    </div>
                </div>
            </div>
        </div>
    </div>  
</div>

<link rel="stylesheet" href="{{ asset('assets/css/globalp.css') }}">

@endsection
