

@extends('layout.main-front')
@section('title') @if( ! empty($title)) {{ $title }} | @endif @parent @endsection

@section('main')

  	<div class="main">
		<div class="custom-container">
		    	<div class="listingbody">
		    
@if($ads->count() <= 0)

<p> No Records Found.</p>
   @endif
 <div class="modern-home-search-bar-wrap">
       <ul class="breadcrumb">
                            <li> <a href="{{ route('home') }}">@lang('app.home')</a> </li>
                            <!--<li> <span>All Projects</span> </li>-->
                        </ul>
                        <br>
			<form class="form-inline" action="{{ route('main_search') }}" method="get">			
                            <div class="searchpanel" style="margin-top: -2%;">

				<input type="text" name="q" placeholder="What you are looking for??">
				<!--<input type="hidden" name="sub_category">-->
<button type="submit" class="btn topnone"> <i class="fa fa-search"></i> GO</button>
			</form>

			</div>


                    </div>
<div class="innerListingbody">
    
                  
					<div class="innerheading green">
						SEARCH RESULTS
					</div>
@if($ads->count() > 0)
					 @foreach($ads as $ad)
					
					
					 	<h3><a href="{{  route('single_ad', [$ad->id, $ad->slug]) }}"><?php echo $ad->title; ?></a></h3>
					 	<div><a href="{{  route('single_ad', [$ad->id, $ad->slug]) }}"><?php echo $ad->type; ?></a></div>




					 @endforeach
					
   @endif
   </div>
				</div>
			</div>
</div>

@endsection


